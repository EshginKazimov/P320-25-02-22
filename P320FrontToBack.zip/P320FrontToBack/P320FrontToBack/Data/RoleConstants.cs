﻿namespace P320FrontToBack.Data
{
    public static class RoleConstants
    {
        public const string AdminRole = "Admin";
        public const string ModeratorRole = "Moderator";
        public const string UserRole = "User";
    }
}
